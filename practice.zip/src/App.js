import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Home from "./Home";
import Details from "./Details";
import Weather from "./Weather";
const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* <Route path="/" element={<Home />} /> */}
        <Route path="/details/:name" element={<Details />} />
        <Route path="/" element={<Weather />} />
      </Routes>
    </BrowserRouter>
  );
};
export default App;
