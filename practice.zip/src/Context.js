import { createContext } from "react";
import { useState } from "react";
const DataContext = createContext();
const InputValueContext = createContext();
const AbilitiesContext = createContext();
const Context = ({ children }) => {
  const [data, setData] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [abilities, setAbilities] = useState([]);
  return (
    <DataContext.Provider value={[data, setData]}>
      <InputValueContext.Provider value={[inputValue, setInputValue]}>
        <AbilitiesContext.Provider value={[abilities, setAbilities]}>
          {children}
        </AbilitiesContext.Provider>
      </InputValueContext.Provider>
    </DataContext.Provider>
  );
};
export default Context;
export { DataContext, InputValueContext, AbilitiesContext };
