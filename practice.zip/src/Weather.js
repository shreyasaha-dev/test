import axios from "axios";
import { useState } from "react";

const Weather = () => {
  const [searchValue, setSearchValue] = useState();
  const [weatherData, setWeatherData] = useState();
  const handleChange = (e) => {
    setSearchValue(e.target.value);
  };
  const searchHandler = async () => {
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${searchValue}&appid=7939b0ffad62f304882ae289288ee36e&units=metric`
      );
      console.log(response.data);
      setWeatherData(response.data);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <input
        placeholder="search places"
        value={searchValue}
        onChange={handleChange}
      />
      <button onClick={searchHandler}>search</button>
      {weatherData && searchValue && (
        <div>
          <h2>temp:{weatherData?.main?.temp} °c</h2>
          <h4>{weatherData?.weather[0]?.description}</h4>
        </div>
      )}
    </>
  );
};
export default Weather;
