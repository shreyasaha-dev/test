import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { AbilitiesContext } from "./Context";
const Details = () => {
  const [abilities, setAbilities] = useContext(AbilitiesContext);
  const params = useParams();
  useEffect(() => {
    const getDetails = async () => {
      try {
        const res = await axios.get(
          `https://pokeapi.co/api/v2/pokemon/${params?.name}`
        );
        console.log(res);
        setAbilities(res.data.abilities);
      } catch (error) {
        console.log(error);
      }
    };
    getDetails();
  }, [params?.name]);
  return abilities.map((item) => {
    return <h2>{item.ability.name}</h2>;
  });
};
export default Details;
