// import { useContext, useEffect } from "react";
// import axios from "axios";
// import { DataContext, InputValueContext } from "./Context";
// import { useNavigate } from "react-router-dom";
// const Home = () => {
//   const navigate = useNavigate();
//   const [data, setData] = useContext(DataContext);
//   const [inputValue, setInputValue] = useContext(InputValueContext);
//   useEffect(() => {
//     const getData = async () => {
//       try {
//         const response = await axios.get("https://pokeapi.co/api/v2/pokemon");
//         console.log(response);
//         setData(response.data.results);
//       } catch (error) {
//         console.log(error);
//       }
//     };
//     getData();
//   }, []);
//   const filterHandler = () => {
//     if (inputValue !== "") {
//       setData(
//         data?.filter((item) => {
//           if (item?.name?.includes(inputValue)) {
//             return item?.name;
//           }
//         })
//       );
//       setInputValue("");
//     }
//   };
//   const resetHandler = async () => {
//     try {
//       const response = await axios.get("https://pokeapi.co/api/v2/pokemon");
//       console.log(response.data.results);
//       setData(response.data.results);
//     } catch (error) {
//       console.log(error);
//     }
//   };
//   const handleDetails = (name) => {
//     navigate(`/details/${name}`);
//   };
//   return (
//     <>
//       <input
//         placeholder="Search"
//         value={inputValue}
//         onChange={(e) => {
//           setInputValue(e.target.value);
//         }}
//       />
//       <button onClick={filterHandler}>Filter</button>
//       <button onClick={resetHandler}>Reset</button>
//       {data?.map((item) => {
//         return (
//           <h3
//             onClick={() => {
//               handleDetails(item?.name);
//             }}
//           >
//             {item?.name}
//           </h3>
//         );
//       })}
//     </>
//   );
// };

import { all } from "axios";
import { useState } from "react";

// export default Home;

// import { useState } from "react";
// const Home = () => {
//   const options = ["cat", "cow", "dog"];
//   const [value, setValue] = useState();
//   const selectOption = (e) => {
//     setValue(e.target.value);
//   };
//   return (
//     <select onChange={selectOption}>
//       {options.map((item) => {
//         return <option value={item}>{item}</option>;
//       })}
//     </select>
//   );
// };
// export default Home;
const Home = () => {
  const [inputValue, setInputValue] = useState();
  const [allValues, setAllValues] = useState([]);
  const [id, setId] = useState("");
  const handleChange = (e) => {
    setInputValue(e.target.value);
  };
  const addTodo = () => {
    if (inputValue !== "") {
      setAllValues((prev) => {
        return [...prev, inputValue];
      });
      setInputValue("");
    }
  };
  const deleteHandler = (i) => {
    setAllValues(
      allValues.filter((item, index) => {
        if (index !== i) {
          return item;
        }
      })
    );
  };
  const editHandler = (item, i) => {
    setInputValue(item);
    setId(i);
  };
  const changeValue = () => {
    setAllValues(
      allValues.map((item, i) => {
        if (id === i) {
          return inputValue;
        } else {
          return item;
        }
      })
    );
    setInputValue("");
  };
  return (
    <>
      <input
        placeholder="add todo"
        value={inputValue}
        onChange={handleChange}
      />
      <button onClick={addTodo}>add</button>
      {id !== "" && <button onClick={changeValue}>change</button>}
      {allValues.map((item, i) => {
        return (
          <>
            <p>{item}</p>
            <button
              onClick={() => {
                deleteHandler(i);
              }}
            >
              delete
            </button>
            <button
              onClick={() => {
                editHandler(item, i);
              }}
            >
              edit
            </button>
          </>
        );
      })}
    </>
  );
};
export default Home;
